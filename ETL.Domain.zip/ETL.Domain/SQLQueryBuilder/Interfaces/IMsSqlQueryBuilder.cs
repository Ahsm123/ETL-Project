﻿using ExtractAPI.DataSources.DatabaseQueryBuilder.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETL.Domain.SQLQueryBuilder.Interfaces;

public interface IMsSqlQueryBuilder : ISqlQueryBuilder
{
}
